/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_csv_uploads`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_csv_uploads`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_csv_uploads` ( `csv_id` mediumint(9) NOT NULL AUTO_INCREMENT, `csv_name` varchar(100) NOT NULL, `csv_real_file_name` varchar(4096) NOT NULL, `csv_orig_file_name` varchar(4096) NOT NULL, `csv_timestamp` datetime DEFAULT NULL, `csv_mapping` text DEFAULT NULL, PRIMARY KEY (`csv_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
