/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_logging`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_logging`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_logging` ( `log_time` datetime NOT NULL, `log_id` varchar(50) NOT NULL, `log_type` enum('FATAL','ERROR','WARN','INFO','DEBUG','TRACE') DEFAULT NULL, `log_msg` varchar(4096) DEFAULT NULL, PRIMARY KEY (`log_time`,`log_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
