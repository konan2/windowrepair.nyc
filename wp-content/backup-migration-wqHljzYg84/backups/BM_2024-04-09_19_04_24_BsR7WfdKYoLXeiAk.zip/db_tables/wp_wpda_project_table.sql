/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_project_table`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_project_table`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_project_table` ( `wpda_table_name` varchar(64) NOT NULL, `wpda_schema_name` varchar(64) NOT NULL DEFAULT '', `wpda_table_setname` varchar(100) NOT NULL DEFAULT 'default', `wpda_table_design` longtext NOT NULL, PRIMARY KEY (`wpda_schema_name`,`wpda_table_name`,`wpda_table_setname`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
