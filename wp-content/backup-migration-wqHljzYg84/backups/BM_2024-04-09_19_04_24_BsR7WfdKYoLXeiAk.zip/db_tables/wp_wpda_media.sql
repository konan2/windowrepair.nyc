/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_media`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_media`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_media` ( `media_schema_name` varchar(64) NOT NULL DEFAULT '', `media_table_name` varchar(64) NOT NULL, `media_column_name` varchar(64) NOT NULL, `media_type` enum('Image','ImageURL','Attachment','Hyperlink','Audio','Video') DEFAULT NULL, `media_activated` enum('Yes','No') DEFAULT NULL, PRIMARY KEY (`media_schema_name`,`media_table_name`,`media_column_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
