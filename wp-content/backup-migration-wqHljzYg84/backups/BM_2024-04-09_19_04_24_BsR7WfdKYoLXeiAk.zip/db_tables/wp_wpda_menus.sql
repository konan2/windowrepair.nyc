/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_menus`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_menus`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_menus` ( `menu_id` mediumint(9) NOT NULL AUTO_INCREMENT, `menu_schema_name` varchar(64) NOT NULL DEFAULT '', `menu_table_name` varchar(64) NOT NULL, `menu_name` varchar(100) NOT NULL, `menu_slug` varchar(100) NOT NULL, `menu_role` varchar(100) DEFAULT NULL, PRIMARY KEY (`menu_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
