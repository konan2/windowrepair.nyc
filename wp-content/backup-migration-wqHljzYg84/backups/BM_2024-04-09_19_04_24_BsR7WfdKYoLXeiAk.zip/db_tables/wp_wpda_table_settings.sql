/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_table_settings`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_table_settings`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_table_settings` ( `wpda_schema_name` varchar(64) NOT NULL DEFAULT '', `wpda_table_name` varchar(64) NOT NULL, `wpda_table_settings` text NOT NULL, PRIMARY KEY (`wpda_schema_name`,`wpda_table_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
