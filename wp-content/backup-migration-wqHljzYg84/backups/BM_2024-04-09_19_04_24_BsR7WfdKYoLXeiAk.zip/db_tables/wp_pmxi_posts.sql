/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_pmxi_posts`; */
/* PRE_TABLE_NAME: `1712689467_wp_pmxi_posts`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_pmxi_posts` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `post_id` bigint(20) unsigned NOT NULL, `import_id` bigint(20) unsigned NOT NULL, `unique_key` text DEFAULT NULL, `product_key` text DEFAULT NULL, `iteration` bigint(20) NOT NULL DEFAULT 0, `specified` tinyint(1) NOT NULL DEFAULT 0, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
