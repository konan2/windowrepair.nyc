/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpda_table_design`; */
/* PRE_TABLE_NAME: `1712689467_wp_wpda_table_design`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_wpda_table_design` ( `wpda_table_name` varchar(64) NOT NULL, `wpda_schema_name` varchar(64) NOT NULL DEFAULT '', `wpda_table_design` text NOT NULL, `wpda_date_created` timestamp NOT NULL DEFAULT current_timestamp(), `wpda_last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(), PRIMARY KEY (`wpda_schema_name`,`wpda_table_name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
