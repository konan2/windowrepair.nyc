/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_pmxi_templates`; */
/* PRE_TABLE_NAME: `1712689467_wp_pmxi_templates`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1712689467_wp_pmxi_templates` ( `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `options` longtext DEFAULT NULL, `scheduled` varchar(64) NOT NULL DEFAULT '', `name` varchar(200) NOT NULL DEFAULT '', `title` text DEFAULT NULL, `content` longtext DEFAULT NULL, `is_keep_linebreaks` tinyint(1) NOT NULL DEFAULT 0, `is_leave_html` tinyint(1) NOT NULL DEFAULT 0, `fix_characters` tinyint(1) NOT NULL DEFAULT 0, `meta` longtext DEFAULT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
